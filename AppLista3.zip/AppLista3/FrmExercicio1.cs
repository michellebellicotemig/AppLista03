﻿using System;
using System.Windows.Forms;

namespace AppLista3
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

        }
    }
}
